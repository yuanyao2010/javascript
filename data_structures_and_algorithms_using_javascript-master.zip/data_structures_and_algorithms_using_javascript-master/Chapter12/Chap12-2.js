var numElements = 100;
var myNums = new CArray(numElements);
myNums.setData();
print(myNums.toString());
